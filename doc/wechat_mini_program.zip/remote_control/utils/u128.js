/*
 Unsigned 128 bit integer math library
*/
//var faultylabs = {};
//faultylabs.u128 = {};

// Hex string to number
function hexval(n) {
	var r = new Array(4)
	n = "0000000000000000000000000000000" + n
	n = n.slice(-32)
	r[3] = parseInt(n.substr(0, 8), 16)
	r[2] = parseInt(n.substr(8, 8), 16)
	r[1] = parseInt(n.substr(16,8), 16)
	r[0] = parseInt(n.substr(24,8), 16)
	return r
}

// internal: u32 to hex string
function _u32ToHex(u) {
	var t = (u >>> 0).toString(16)
	return "00000000".substr(0, 8 - t.length) + t;
}

// u128 to hex string
function varhex(n) {
	var r = ""
	for (var i = 0; i < 4; i++) {
		r =   _u32ToHex(n[i]) + r
	}
	return r
}

// internal: array dup
function _cloneArray(arr) {
	return arr.slice(0);
}

// // Left shift
// faultylabs.u128.shl = function(n, s) {
// 	var ns = faultylabs.u128._cloneArray(n)
// 	for (var i = 0; i<s; i++) {
// 		ns[3] = ((ns[3]<<1) | (ns[2] >>> 31))
// 		ns[2] = ((ns[2]<<1) | (ns[1] >>> 31))
// 		ns[1] = ((ns[1]<<1) | (ns[0] >>> 31))
// 		ns[0] = ((ns[0]<<1))
// 	}
// 	return ns;
// }

// // Unsigned right shift
// faultylabs.u128.shr = function(n, s) {
// 	var ns = faultylabs.u128._cloneArray(n)
// 	for (var i = 0; i<s; i++) {
// 		ns[0] = ( (ns[0]>>>1) | (ns[1]<<31 ) ) >>> 0
// 		ns[1] = ( (ns[1]>>>1) | (ns[2]<<31 ) ) >>> 0
// 		ns[2] = ( (ns[2]>>>1) | (ns[3]<<31 ) ) >>> 0
// 		ns[3] = ( (ns[3]>>>1))
// 	}
// 	return ns;
// }

// New u128 = 0
function zero() {
	return [0, 0, 0, 0];
}

// // New u128 = 1
// faultylabs.u128.one = function() {
// 	return [1, 0, 0, 0];
// }

// // Bit test
// faultylabs.u128.btest = function(n, b) {
// 	if (b>127) { 
// 		return false 
// 	}
// 	var t = n[b>>>5]	
// 	return (t >>> (b & 0x1F)) & 1	
// }


/*
 Mul: u128 * u128 -> u128 
 Results greater or equal to 2^128 are _truncated_ to 128 bit

 Algo:
 Variation on schoolbook multiplication of two '32 bit * 4' quantities:
 a[0..3] * b[0..3] -> c[0..3]

 c[3]       c[2]       c[1]       c[0]
 127.....96 95......64 63......32 31.......0
 ---------- ---------- ---------- ----------
                       |.....a[0]*b[0].....|  +
 ...........................................
            |.....a[1]*b[0].....|             +
 ...........................................
 |.....a[2]*b[0].....|                        +
 ...........................................
 a[3]*b[0]                                    +
 ...........................................
            |.....a[0]*b[1].....|             +
 ...........................................
 |.....a[1]*b[1].....|                        +
 ...........................................
 a[2]*b[1]                                    +
 ...........................................
 |.....a[0]*b[2].....|                        +
 ...........................................
 a[1]*b[2]                                    +
 ...........................................
 a[0]*b[3]                                    =
 ---------- ---------- ---------- ----------
 c[3]       c[2]       c[1]       c[0]

Things are complicated somewhat due to the apparent lack of a 32 by 32 bit integer 
multiplication yielding 64 bit integer results.
According to the spec:

ECMA 262 5th ed
11.5.1 Applyingthe*Operator
"The result of a floating-point multiplication is governed by the rules of IEEE 754 binary double-precision arithmetic"
"[...] the product is computed and rounded to the nearest representable value using IEEE 754 round-to-nearest mode."

Double precision IEEE 754 is not precise enough to exactly represent all possible 64 bit integers, therefore
a custom 32 bit unsigned multiplication function umul32shl was added to the library.

*/
function mul(n1, n2) {
	//var u = faultylabs.u128
	var t0 = umul32shl(n1[0], n2[0], 0)
	t0 = add(t0, umul32shl(n1[1], n2[0], 1))
	t0 = add(t0, umul32shl(n1[2], n2[0], 2))
	t0 = add(t0, umul32shl(n1[3], n2[0], 3))

	t0 = add(t0, umul32shl(n1[0], n2[1], 1))
	t0 = add(t0, umul32shl(n1[1], n2[1], 2))
	t0 = add(t0, umul32shl(n1[2], n2[1], 3))
	
	t0 = add(t0, umul32shl(n1[0], n2[2], 2))
	t0 = add(t0, umul32shl(n1[1], n2[2], 3))

	t0 = add(t0, umul32shl(n1[0], n2[3], 3))

	return t0
}

/* 
internal mul u32 * u32 -> u64 (extended to u128),
Result is left-shifted by '32 * offset' bits 
(May overflow to 160 bits, in which case it's truncated)
*/
function umul32shl(a, b, offset) {
	//var u = faultylabs.u128
	var retval = [0,0,0,0];
	var al = 0xFFFF & a;
	var ah = (0xFFFF0000 & a) >>> 16;
	var bl = 0xFFFF & b;
	var bh = (0xFFFF0000 & b) >>> 16;

	var ahbl = ah*bl
	var albh = al*bh
	var ahbh = ah*bh

	retval[offset]  = al*bl
	
	var tmp = [0,0,0,0,0] // the fifth dword (overflow to 160 bits) will be ignored
	tmp[offset] = ahbl << 16
	tmp[1+offset] = ahbl >>> 16 
	retval = add(retval, tmp)

	var tmp = [0,0,0,0,0]
	tmp[0+offset] = albh << 16
	tmp[1+offset] = albh >>> 16 
	retval = add(retval, tmp)
	
	if (offset < 3) { 
		var tmp = [0,0,0,0]
		tmp[1+offset] = ahbh 
		retval = add(retval, tmp)
	}
	return retval;
}

// Add
function add (n1, n2) {
	var retval = zero()
	var carry = 0
	for (var i = 0; i < 4; i++) {
		retval[i] = (0x0FFFFFFFF & (n1[i] + n2[i] + carry)) >>>  0
		if (_cmp32ABOVE(n1[i], retval[i])) {
			carry = 1
		} else {
			carry = 0
		}
	}
	return retval;
}

// Unsigned 32 bit comparison, true if n1 is above n2 
// The >>> 0 is to force conversion to unsigned int
// Most integers ops in the spec return *signed* 32 bit integers
// Luckily, there's ">>>"
//
// ECMA 262 5th ed
// 11.7.3 The Unsigned Right Shift Operator ( >>> )
// 8 [...] The result is an unsigned 32-bit integer.
function _cmp32ABOVE(n1, n2) {
	return (n1 >>> 0) > (n2 >>> 0)
}

// Sub: subtract n2 from n1
function sub(n1, n2) {
	var retval = zero()
	var carry = 0
	for (var i = 0; i < 4; i++) {
		retval[i] = (n1[i] - n2[i] - carry) >>> 0
		// if (n2 > n1) or (n1=0 and carry-is-set)
		if (_cmp32ABOVE(n2[i], n1[i]) || (!n1[i] && carry) ) {
			carry = 1
		} else {
			carry = 0
		}
	}
	return retval;
}

// // Binary AND
// faultylabs.u128.and = function(n1, n2) {
// 	var retval = faultylabs.u128.zero()
// 	for (var i = 0; i < 4; i++) {
// 		retval[i] = n1[i] & n2[i];
// 	}
// 	return retval;
// }

// // Binary OR
// faultylabs.u128.or = function(n1, n2) {
// 	var retval = faultylabs.u128.zero()
// 	for (var i = 0; i < 4; i++) {
// 		retval[i] = n1[i] | n2[i];
// 	}
// 	return retval;
// }

// // Binary NOT
// faultylabs.u128.not = function(n1) {
// 	var retval = faultylabs.u128.zero()
// 	for (var i = 0; i < 4; i++) {
// 		retval[i] = ~n1[i] 
// 	}
// 	return retval;
// }


// // Binary XOR
// faultylabs.u128.xor = function(n1, n2) {
// 	var retval = faultylabs.u128.zero()
// 	for (var i = 0; i < 4; i++) {
// 		retval[i] = n1[i] ^ n2[i];
// 	}
// 	return retval;
// }

// Comparison
// n1>n2 ->  1
// n1<n2 -> -1 
// n1=n2 ->  0
function comparison(n1, n2) {
	for (var i = 4; i >= 0; --i) {
		if (_cmp32ABOVE(n1[i], n2[i])) {
			return 1
		} else if (_cmp32ABOVE(n2[i], n1[i])) {
			return -1
		}
	}
	return 0
}


/*
internal: convert js fp number to 128bit uint
*/
function to128(n) {
	while (n >= Math.pow(2, 128)) {
		n = n / 2
	}
	var n3 = Math.floor(n / Math.pow(2, 96)) 
	var n2 = (Math.floor(n / Math.pow(2, 64)) & 0xFFFFFFFF) 
	var n1 = (Math.floor(n / Math.pow(2, 32)) & 0xFFFFFFFF) 
	var n0 = (Math.floor(n) & 0x0FFFFFFFF) 
	var retval = [n0, n1, n2, n3]
	return retval
}

/*
internal: convert 128bit uint to Number
*/
function toFp (n) {
	var retval = Math.pow(2, 96) * n[3] 
	retval    += Math.pow(2, 64) * n[2] 
	retval    += Math.pow(2, 32) * n[1] 
	retval    += (1.0 * n[0])
	return retval
}


/*

 Div/Mod: return [quotient, remainder] of n1 / n2

 Very brief algo description:

 Calculate unsigned 128 bit integer quotient and remainder of 'n1 / n2'
  where 'n1' and 'n2' are unsigned 128 bit integer quantities
 
 - Guess the quotient q using floating point approximations of n1 and n2
 - Iteratively refine q until n1 >= (n1 - (q * n2)) > n2 
 - Return quotient  = q  
          remainder = n1 - (q * n2)
*/
function divmod(n1, n2) {
	//var u = faultylabs.u128;
	if (comparison(n2, zero) == 0) { 
		throw "Divide by zero!" 
	}
	var cmp = comparison(n1, n2);
	if (cmp < 0)  {
		return [[0,0,0,0], n1]
	} else if (cmp == 0 ) {
		return [[1,0,0,0], [0,0,0,0]]
	} else {
		// initially: remainder = n1 and quotient = 0
		var rem = _cloneArray(n1)
		var q128 = [0, 0, 0, 0]
		var delta_op = 0 // -1 = delta sub, +1 = delta add, 0 = no delta
		var fp_n2  = toFp(n2) 
		for(;;) {
			var fp_rem  = toFp(rem)
			var delta_q = (fp_rem / fp_n2) 
			if (delta_q < 1 || delta_q == Infinity) delta_q = 1.0; // round up, if the factor is too small
			var delta_q128 = to128(delta_q)
			if (delta_op < 0) {
				q128 = sub(q128, delta_q128)
			} else {
				q128 = add(q128, delta_q128)
			}
			var converge = mul(n2, q128)
			delta_op = comparison(n1, converge)
			if (delta_op == 0) {
				return [q128, [0,0,0,0]]
			}
			if (delta_op > 0) {
				rem = sub(n1, converge)			
				if (comparison(rem, n2) < 0) {
					return [q128, rem]
				}
			} else {
				rem = sub(converge, n1)			
			}
		}
	}	
}


// Div: quotient n1/n2
function div(n1, n2) {
	return divmod(n1, n2)[0];
}

// // Mod: remainder n1/n2
// faultylabs.u128.mod = function(n1, n2) {
// 	return faultylabs.u128.divmod(n1, n2)[1];
// }

function pairEncode1(code) {
  code = sub(mul(code, [3, 0, 0, 0]), [101, 0, 0, 0]);        // code * 3 - 101;
  code = add(mul(code, [7, 0, 0, 0]), [103, 0, 0, 0]);        // code * 7 + 103;
  code = sub(mul(code, [11, 0, 0, 0]), [56457666, 0, 0, 0]);  // code * 11 - 56457666;
  code = sub(mul(code, [1001, 0, 0, 0]), [109, 0, 0, 0]);     // code * 1001 - 109;
  code = add(mul(code, [23, 0, 0, 0]), [100000001, 0, 0, 0]); // code * 23 + 100000001;
  code = sub(mul(code, [31, 0, 0, 0]), [119, 0, 0, 0]); // code * 31 - 119;
  code = sub(mul(code, [41, 0, 0, 0]), [131, 0, 0, 0]); // code * 41 - 131;
  code = sub(mul(code, [47, 0, 0, 0]), [133, 0, 0, 0]); // code * 47 - 133;
  code[2] = 0;
  code[3] = 0;
  return code;
}

module.exports = {
  hexval : hexval ,
  add: add,
  sub: sub,
  div: div,
  mul: mul,
  varhex: varhex,
  pairEncode1: pairEncode1
}
