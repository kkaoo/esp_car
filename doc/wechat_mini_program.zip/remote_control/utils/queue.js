/**
 *  queue 排列 【0】【1】【2】【3】【4】......
 *  add data -> [0], 所以数据后移，最后的数据丢弃
 *  remove data 删除最早的一个数据[point]
 */

//构造
function Queue(res){
  var point = 0
  var fifo = new ArrayBuffer(res)
  var add = this.add
  console.log('queue 构造')

  this.clear = function () {
    for (var i = 0; i < fifo.byteLength; i++) {
      fifo[i] = 0;
    }
    point = 0;
  }

  this.add = function (data) {
    for (var i = fifo.length - 1; i != 0; i--)
      fifo[i] = fifo[i - 1];
    fifo[0] = data;

    if (point < fifo.length)
      point++;
  }

  this.compAndAdd = function (data) {
    if (point > 0) {
      if ((fifo[0] > 0 && data < 0) || (fifo[0] < 0 && data > 0))
        add(data);
    } else {
      add(data);
    }
  }

  this.remove = function () {
    if (point != 0) {
      fifo[point - 1] = 0;
      point--;
    }
  }

  this.update = function (i) {
    if (point > 0)
      fifo[0] = i;
  }

  this.getAt = function (i) {
    return (fifo[i]);
  }

  this.poll = function () {
    var ret = 0;
    if (point != 0) {
      ret = fifo[point - 1];
      fifo[point - 1] = 0;
      point--;
    }
    return ret;
  }
  
}

module.exports = Queue