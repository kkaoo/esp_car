const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function getChecksum(data){
  var sum = 0;
  for (var i = 0; i < data.byteLength - 1; i++) {
    sum += data[i];
  }
  sum &= 0xff;  
  return sum;
}

function isChecksumOK(res){
  var data = res
  //console.log(data);
  if(data.byteLength>20){
    console.log('isChecksumOk Err:',data.byteLength)
    return false;
  }

  if ((data[1] + 2) != data.byteLength) {
    console.log('isChecksumOk Err byteLength ', data[1],data.byteLength)
    return false;
  } 

  if (data[0] != 0xaa) {
    console.log('isChecksumOk Err 0xaa ', data[0])
    return false;
  } 

  var sum = 0;
  for (var i = 0; i < data.byteLength - 1; i++) {
    sum += data[i];
  }
  sum &= 0xff;
  
  if(data[data.byteLength - 1] != sum){
    console.log('isChecksumOk Err sum ', sum, data[data.byteLength - 1])
      return false;
  } 
  return true;
}

function buf2hex(buffer) {
  return Array.prototype.map.call(new Uint8Array(buffer), x => ('00' + x.toString(16)).slice(-2)).join('');
}

function hex2buf(hex) {
  var array = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
    return parseInt(h, 16)
  }))
  return array;
}

function getInt16(a, b){
  var d2 = (a<<8) + b
  if(d2>0x7fff)
      d2 = d2 - 0x10000
  return d2
}

module.exports = {
  formatTime: formatTime,
  isChecksumOK: isChecksumOK,
  getChecksum: getChecksum,
  buf2hex: buf2hex,
  hex2buf: hex2buf,
  getInt16: getInt16
}
