const app = getApp()

var util = require('../../utils/util.js')

var connectedDeviceId
var notifyUpdateFreq = 0
var interval,timer,timer2

var txId = { service: '', characteristic: '' }

var CenterX = 151, CenterY = 151, RockerCircleR = 90, SmallRockerCircleR = 30
var cp1 = {x:CenterX,y:CenterY}
const M_PI = 3.14159265358979323846264338327950288

var cmdCarControl = ''
var cmdCount = 0

const udp = wx.createUDPSocket()

Page({

  data: {
    isConnected: false,
    lr: 0,
    fb: 0,
    speed: 0,
    rad: 0,
    voltage: 0,
    tempa: 0,
    cb1: false,
    cb2: false,
    cb3: false,
    cb4: true,
    cb4Text: '左右双驱马达',
    notify_flash:false,
  },

  checkbox1: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e ,e.detail.value.length)
    this.setData({
      cb1: e.detail.value.length == 1 ? true : false
    })
  }, 
  checkbox2: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value.length)
    this.setData({
      cb2: e.detail.value.length == 1 ? true : false
    })
  }, 
  checkbox3: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value.length)
    this.setData({
      cb3: e.detail.value.length == 1 ? true : false
    })
  },
  checkbox4: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value.length)
    this.setData({
      cb4: e.detail.value.length == 1 ? true : false,
      cb4Text: e.detail.value.length == 0 ? '前后马达' : '左右双驱马达'
    })
  },

  searchBluetooth: function () {
    var that = this
    //wx.reLaunch({
    //wx.navigateTo({
    wx.redirectTo({
      url: '../search/search?page=bleCar'
    })
  },

  sendData: function (res) {
    var that = this;

    if (udp == null)
      return

    if (cmdCarControl == res){
      if(cmdCount > 5)
        return
      cmdCount++
    }
    else{
      cmdCount=0
      cmdCarControl = res
    }

    udp.send({
      address: '192.168.4.1',
      port: 10000,
      message: cmdCarControl
    })
  },

  processData: function (res) {
    var that = this
    var data = util.hex2buf(res);

    notifyUpdateFreq++
    var voltage = util.getInt16(data[3], data[2]) *6 / 1000 //1000
    var tempa = util.getInt16(data[1], data[0]) / 100
    var notify_flash = !this.data.notify_flash
    that.setData({
      voltage:voltage,
      tempa:tempa,
      notify_flash:notify_flash
    })
  },

  onLoad: function (options) {
    var that = this

    console.log("OnLoad");
  
    if(udp!=null)
    {
      console.log(udp)
      const port = udp.bind()
      console.log(port)

      udp.onMessage(function(res){
        console.log(res)
      })

      udp.onError(function(res){
        console.log(res)
      })
    }
  },


  onReady: function () {
    console.log('index OnReady')
    var that = this

    clearInterval(interval)
    clearInterval(timer)

    this.drawBigBall()
    var that = this

    interval = setInterval(function () {
      that.drawSmallBall()
    }, 25)

    timer = setInterval(function () {
      //console.log('timer:', notifyUpdateFreq)
      notifyUpdateFreq = 0
      
      var mode = that.data.cb4
      var fb=that.data.fb
      var lr = that.data.lr
      var speed = new Int16Array(1);

      speed = that.data.speed * 10
      var speed_l = 0
      var speed_r = 0

      if(mode==false)
      {
        if(fb=="前进")
          speed = that.data.speed
        else if(fb=="后退")
          speed = -that.data.speed
        else
          speed = 0;


        if(lr=="左")
          speed = 100
        else if(lr=="右")
          speed = -100
        else
          speed = 0

      }
      else
      {
        if(lr == '左'){
          speed_l = -speed
          speed_r = speed
        }
        else if(lr == '右'){
          speed_l = speed
          speed_r = -speed
        }
        else{
          if(fb == '前进'){
            speed_l = speed
            speed_r = speed
          }
          else if(fb == "后退"){
            speed_l = -speed
            speed_r = -speed
          }
        }
      }

      var str = 'control_cmd:speed_l=' + speed_l.toString()+':speed_r='+speed_r.toString()
      that.sendData(str);
      // console.log(str)
      
    }, 100)

  },

  drawBigBall: function () {
    var context = wx.createContext()
    context.beginPath(0)
    context.arc(CenterX, CenterY, RockerCircleR + SmallRockerCircleR/3, 0, Math.PI * 2)
    context.setFillStyle('#ffffff')
    context.setStrokeStyle('#aaaaaa')
    context.fill()
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'big-ball',
      actions: context.getActions()
    })
  },

  drawSmallBall: function () {
    var x,y
    var strokeStyle = 'rgba(1,1,1,0)'

    x = cp1.x;
    y = cp1.y;
    var context = wx.createContext()
    context.beginPath(0)
    context.arc(x, y, SmallRockerCircleR, 0, Math.PI * 2)
    context.setFillStyle('#1aad19')
    context.setStrokeStyle(strokeStyle)
    context.fill()
    // context.stroke()
    wx.drawCanvas({
      canvasId: 'small-ball',
      actions: context.getActions()
    })
  },


  onShow: function () {
    if (wx.setKeepScreenOn) {
      wx.setKeepScreenOn({
        keepScreenOn: true,
        success: function (res) {
          //console.log('保持屏幕常亮')
        }
      })
    }

    wx.setNavigationBarTitle({
      title: (this.data.isConnected ? this.data.name : '车车来了')
    })
  },

  onHide: function () {
    console.log('index OnHide')

    var that = this
    if (this.data.isConnected) {
      wx.closeBLEConnection({
        deviceId: this.data.connectedDeviceId,
        success: function (res) {
          console.log(res)
          that.setData({
            isConnected: false
          })
        }
      })
    }
  },

  onUnload: function () {
    console.log('index OnUnload')
    var that = this

    clearInterval(interval)
    clearInterval(timer)

    if (this.data.isConnected) {
      wx.closeBLEConnection({
        deviceId: connectedDeviceId,
        success: function (res) {
          console.log(res)
          that.setData({
            isConnected: false
          })
        }
      })
    }
  },
  
  mytouchstart: function(e){
  },

  mytouchend: function(e){
    cp1 = {x:CenterX,y:CenterY,ox:0,oy:0}

    this.getSpeed(CenterX,CenterY,cp1.x, cp1.y)
  },

  mytouchmove: function(e){
  //  console.log(e.touches[0].pageX ,e.currentTarget.offsetLeft,e.touches[0].pageY , e.currentTarget.offsetTop);

    //var x = e.touches[0].pageX - e.currentTarget.offsetLeft;
    //var y = e.touches[0].pageY - e.currentTarget.offsetTop;
    var x = e.touches[0].x;
    var y = e.touches[0].y;

    if (Math.sqrt(Math.pow(Math.abs(x) - CenterX, 2) + Math.pow(Math.abs(y) - CenterY, 2)) >= RockerCircleR) {
      //console.log("out");
      //得到摇杆与触屏点所形成的角度
      var tmpRad = this.getRad(CenterX,CenterY,x,y)
      var xy = this.getXY(CenterX, CenterY, RockerCircleR,tmpRad)
      cp1.x = xy[0]
      cp1.y = xy[1]
    }
    else
    {
      //console.log("in");
      cp1.x = x
      cp1.y = y
    }

    this.getSpeed(CenterX, CenterY, x, y)
    
  },

  getRad: function(px1,py1,px2,py2) {
    //得到两点X的距离
    var x = px2 - px1;
    //得到两点Y的距离
    var y = py1 - py2;
    //算出斜边长
    var xie = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    //得到这个角度的余弦值（通过三角函数中的定理 ：邻边/斜边=角度余弦值）
    var cosAngle = x / xie;
    //通过反余弦定理获取到其角度的弧度
    var rad = Math.acos(cosAngle);
    //注意：当触屏的位置Y坐标<摇杆的Y坐标我们要取反值-0~-180
    if (py2 < py1) {
        rad = -rad;
    }
    return rad;
  },

  getXY: function(centerX,centerY,R,rad) {
      //获取圆周运动的X坐标
    var x = (R * Math.cos(rad)) + centerX;
      //获取圆周运动的Y坐标
    var y = (R * Math.sin(rad)) + centerY;
      //subview.center = curr_point;
    return [x,y];
  },

  getSpeed: function(cx,cy,px,py){
    //Step1: 计算距离圆心距离
    var x = px - cx;
    var y = py - cy;
    var r = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    var RGap = RockerCircleR - SmallRockerCircleR;
    var rOffset = r - SmallRockerCircleR;
    
    var lr,fb,speed,SpdShift
    if(rOffset<=0)//如果在内圈内,STOP
    {
        SpdShift = 0;
        speed = 0;
        lr = fb = "停止"
    }
    //长度扩展可以做换挡用
    else
    {
        var aa = new Uint8Array(1)
        aa[0] = rOffset / (RGap / 100);

        //1 ~ 100
        //30 ~ 100
        aa[0] = aa[0] / (100 / 70) + 30

        speed = aa[0]>100?100:aa[0];

        if(speed==0)
          SpdShift = 0;
        else
        {
          aa[0] = speed/(100/4)
          SpdShift = aa[0]+1
        }
    }
    
    //Step2: 计算弧度判断位置
    var cosAng = x / r;
    var rad = Math.acos(cosAng);
    if (y<0) {
        rad =   (-rad + 2*M_PI);
    }
    //System.out.println("====>SpdShift is:"+SpdShift+" and rOffset is "+rOffset);
    //右下：0M_PI~1/3M_PI
    if(rad>0&&rad<=1/3*M_PI)
    {
      lr = "右"
      fb = "后退"
    }
    //下：1/3M_PI~2/3M_PI
    else if(rad>1/3*M_PI&&rad<= 2/3*M_PI)
    {
      lr = "停止"
      fb = "后退"
    }
    //左下：2/3M_PI~M_PI
    else if(rad>2/3*M_PI&&rad<= M_PI)
    {
      lr = "左"
      fb = "后退"
    }
    //左上：M_PI~4/3M_PI
    else if(rad> M_PI&&rad<= 4/3*M_PI)
    {
      lr = "左"
      fb = "前进"
    }
    //上：4/3M_PI~5/3M_PI
    else if(rad> 4/3*M_PI && rad<= 5/3*M_PI)
    {
      lr = "停止"
      fb = "前进"
    }
    //右上：5/8M_PI~2M_PI
    else if(rad> 5/3*M_PI&&rad<= 2*M_PI)
    {
      lr = "右"
      fb = "前进"
    }
    
    if(speed==0)
    {
      lr = fb = "停止"
    }

    // console.log(lr + " " + fb + " " + speed + " " + SpdShift + " " +rad)

    this.setData({
      lr:lr,
      fb:fb,
      speed:speed,
      rad:(rad*10|0)
    })
    return[lr,fb,speed]
  }
})
